Requirements: -Jailbroken iPhone
              -LockHTML4 (http://cydia.saurik.com/package/com.bushe.lockhtml4/)
              -iFile or similar file manager software (http://cydia.saurik.com/package/eu.heinelt.ifile/)

Instructions: -Navigate to "/var/mobile/Library/LockHTML" using iFile. Create a folder if the directory doesn't exist.
              -Copy Flat Clock.theme into the directory.
              -Go to settings and navigate to LockHTML4. Make sure "Enable HTML" is on. Click "Select Widget" and then select Flat Clock.
              -That should be it. Turn your phone off and go to the lockscreen. You should see the theme.