var TwentyFourHour = false;
var Scale = "1";
var CustomChargeString = "Default";
var GreenChargeIcon = false;