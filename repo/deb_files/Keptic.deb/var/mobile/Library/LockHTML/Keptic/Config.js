var BackgroundColor = "rgba(0,0,0,.4)";
var TopOffset = "43.5vw";
var LeftOffset = "0px";
var FontSize = '13vw';
var MilitaryTime = false;
var LeadingZero = true;
